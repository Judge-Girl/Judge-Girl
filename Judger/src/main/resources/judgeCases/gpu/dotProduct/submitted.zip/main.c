#include <stdio.h>
#include <assert.h>
#include <inttypes.h>
#include <CL/cl.h>
#include <omp.h>
#define MAXG 10
#define MAXK 1024
#define MAXN 67108870
#define LOCAL_SIZE 128
#define BLK 128
int main(int argc, char *argv[]){
    int N;
    uint32_t key1,key2;
    cl_int status; //debug
    //platform
    cl_platform_id platform_id;
    cl_uint platform_num;
    clGetPlatformIDs(1, &platform_id, &platform_num);
    //device
    cl_device_id GPU[MAXG];
    cl_uint GPU_num;
    clGetDeviceIDs(platform_id, CL_DEVICE_TYPE_GPU, MAXG, GPU, &GPU_num);
    //context
    cl_context context = clCreateContext(NULL, GPU_num=1, GPU, NULL, NULL, &status);
    //command queue
    cl_command_queue cmdQ = clCreateCommandQueue(context, GPU[0], 0, &status);
    //program (with source)
    FILE *fp = fopen("vecdot.cl","r");
    char kernelBuffer[MAXK];
    const char *kernelSource = kernelBuffer;
    size_t kernelLength = fread(kernelBuffer, 1, MAXK, fp);
    cl_program program = clCreateProgramWithSource(context, 1, &kernelSource, &kernelLength, &status);
    //build program
    clBuildProgram(program, GPU_num, GPU, NULL, NULL, NULL);
    //create kernel
    cl_kernel kernel = clCreateKernel(program, "vec_dot", &status);
    //output vector and create buffer
    cl_uint* C = (cl_uint*)malloc(MAXN*sizeof(cl_uint));
    cl_mem buffC = clCreateBuffer(context, CL_MEM_WRITE_ONLY, (MAXN/(BLK*LOCAL_SIZE)+10)*sizeof(cl_uint), C, &status);
    while (scanf("%d %" PRIu32 " %" PRIu32, &N, &key1, &key2) == 3) {
            int N2 = (N-1)/BLK+1;
            int N3 = ((N2-1)/LOCAL_SIZE+1)*LOCAL_SIZE;
            size_t globalThreads[] = {N3};
            size_t localThreads[] = {LOCAL_SIZE};
            //printf("%d %d\n",N2, N3);
 
            //set arg
            clSetKernelArg(kernel, 0, sizeof(cl_uint), (void*)&N);
            clSetKernelArg(kernel, 1, sizeof(cl_uint), (void*)&key1);
            clSetKernelArg(kernel, 2, sizeof(cl_uint), (void*)&key2);
            clSetKernelArg(kernel, 3, sizeof(cl_mem), (void*)&buffC); 
            //set shape
            clEnqueueNDRangeKernel(cmdQ, kernel, 1, NULL, globalThreads, localThreads, 0, NULL, NULL);
            clEnqueueReadBuffer(cmdQ, buffC, CL_TRUE, 0, N3/LOCAL_SIZE*sizeof(cl_uint), C, 0, NULL, NULL);
            uint32_t sum = 0;
            //omp_set_num_threads(2);
            //#pragma omp parallel for schedule(static) reduction(+: sum)
            for (int i = 0; i < N3/LOCAL_SIZE; i++) {
                //printf("%d %u\n",i,C[i]);
                sum += C[i];
            }         
            printf("%" PRIu32 "\n", sum);
    }
    free(C);
    clReleaseContext(context);    /* context etcmake */
    clReleaseCommandQueue(cmdQ);
    clReleaseProgram(program);
    clReleaseKernel(kernel);
    clReleaseMemObject(buffC);
    return 0;
}
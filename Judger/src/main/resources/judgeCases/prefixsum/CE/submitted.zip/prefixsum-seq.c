
#include <stdio.h>
#include <stdlib.h>
#include "utils.h"

 
int main() {
    This should be a compile error
    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include "utils.h"


int main() {
    while(1) {} // infinite-loop for TLE
    return 0;
}